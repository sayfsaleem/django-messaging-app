const HttpStatusCode = {
  OK: 200,
  CREATED: 201,
};

export default HttpStatusCode;
